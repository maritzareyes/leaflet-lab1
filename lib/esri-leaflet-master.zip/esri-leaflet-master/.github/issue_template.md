* Browser and version:

ie: Chrome 51, IE11

* Version of Leaflet (`L.version`):

0.7.7, 1.0.0?

* Version of esri Leaflet (`L.esri.VERSION`):

1.0.4, 2.0.3, `master`?

Steps to reproduce the error:

1. first do this
2. then do this

What happens is [X].

I was expecting [Y].

(if possible, create a [jsbin](http://jsbin.com/dagilag/edit?html,output) that demonstrates the problem)

* Optional: I'm *not* using the [CDN](http://www.jsdelivr.com/projects/leaflet.esri), I'm loading/bundling the library using:

[webpack](https://webpack.github.io/), [browserify](http://browserify.org/), [RequireJS](http://requirejs.org/)?
